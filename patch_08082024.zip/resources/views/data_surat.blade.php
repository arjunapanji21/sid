@extends('layout')

@section('content')

<h1 class="text-xl font-semibold">Data Surat</h1>


@endsection