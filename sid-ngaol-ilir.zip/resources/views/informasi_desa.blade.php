@extends('layout')

@section('content')

<h1 class="text-xl font-semibold">Informasi Desa</h1>


@endsection