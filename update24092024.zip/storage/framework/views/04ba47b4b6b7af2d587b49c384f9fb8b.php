

<?php $__env->startSection('content'); ?>

<h1 class="text-xl font-semibold">Arsip Surat</h1>
<section class="">
    <div class="">
        <!-- Start coding here -->
        <div class="bg-white dark:bg-gray-800 relative shadow-md sm:rounded-lg overflow-hidden">
            <div class="flex flex-col md:flex-row items-center justify-between space-y-3 md:space-y-0 md:space-x-4 p-4">
                
                
            </div>
            <div class="overflow-x-auto min-h-80">
                <table class="text-sm w-full text-left text-gray-500 dark:text-gray-400">
                    <thead class="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400">
                        <tr>
                            <th scope="col" class="px-4 py-3">No. Surat</th>
                            <th scope="col" class="px-4 py-3">Tgl. Pengajuan</th>
                            <th scope="col" class="px-4 py-3">Diajukan Oleh</th>
                            <th scope="col" class="px-4 py-3">Jenis Surat</th>
                            <th scope="col" class="px-4 py-3">Status</th>
                            <th scope="col" class="px-4 py-3">
                                <span class="sr-only">Actions</span>
                            </th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $pengajuan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="border-b dark:border-gray-700">
                            <th scope="row" class="px-4 py-3 font-medium text-gray-900 whitespace-nowrap dark:text-white"><?php echo e($row->no_surat); ?></th>
                            <td class="px-4 py-3"><?php echo e(date('d/m/Y', strtotime($row->created_at))); ?></td>
                            <td class="px-4 py-3"><?php echo e($row->user->nama); ?></td>
                            <td class="px-4 py-3"><?php echo e($row->jenis_surat); ?></td>
                            <td class="px-4 py-3">
                                <span class="bg-blue-100 text-blue-800 text-xs font-medium me-2 px-2.5 py-0.5 rounded dark:bg-blue-900 dark:text-blue-300"><?php echo e($row->status_pengajuan); ?></span></td>
                            <td class="px-4 py-3 flex items-center justify-end">
                                <button id="data<?php echo e($row->id); ?>-button" data-dropdown-toggle="data<?php echo e($row->id); ?>" class="inline-flex items-center p-0.5 text-sm font-medium text-center text-gray-500 hover:text-gray-800 rounded-lg focus:outline-none dark:text-gray-400 dark:hover:text-gray-100" type="button">
                                    <svg class="w-5 h-5" aria-hidden="true" fill="currentColor" viewbox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M6 10a2 2 0 11-4 0 2 2 0 014 0zM12 10a2 2 0 11-4 0 2 2 0 014 0zM16 12a2 2 0 100-4 2 2 0 000 4z" />
                                    </svg>
                                </button>
                                <div id="data<?php echo e($row->id); ?>" class="hidden z-10 w-44 bg-white rounded divide-y divide-gray-100 shadow dark:bg-gray-700 dark:divide-gray-600">
                                    <ul class="py-1 text-sm text-gray-700 dark:text-gray-200" aria-labelledby="data<?php echo e($row->id); ?>-button">
                                        <li>
                                            <a href="<?php echo e(route('show_pengajuan_surat', $row->id)); ?>" class="block py-2 px-4 hover:bg-gray-100 dark:hover:bg-gray-600 dark:hover:text-white">Download</a>
                                        </li>
                                        
                                    </ul>
                                    <div class="py-1">
                                        <a href="<?php echo e(route('hapus_pengajuan_surat', $row->id)); ?>" onclick="return confirm('Hapus pengajuan surat ini?')" class="block py-2 px-4 text-sm text-gray-700 hover:bg-gray-100 dark:hover:bg-gray-600 dark:text-gray-200 dark:hover:text-white">Hapus</a>
                                    </div>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    </section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\SID_NGAO_ILIR_ANDROID\content\resources\views/pengajuan_surat.blade.php ENDPATH**/ ?>